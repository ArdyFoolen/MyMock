﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestMyMock
{
	public interface IExample
	{
		string ExampleMethod();
		int MagicNumber(int number);
	}
}
